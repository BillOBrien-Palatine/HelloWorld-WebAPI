﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using HelloWorld.Models;

namespace HelloWorld.Controllers
{
    public class ProductController : ApiController
    {
        Product[] products =
        {
            new Product {Id = 0, Name = "Milk" , Dept = "Dairy"},
            new Product {Id = 1, Name = "Cereal", Dept = "Breakfast" },
            new Product {Id = 2, Name = "Orange" , Dept = "Produce"},
            new Product {Id = 3, Name = "Apple" , Dept = "Produce"},
            new Product {Id = 4, Name = "Banana" , Dept = "Produce"},
            new Product {Id = 14, Name = "Burger" , Dept = "Meat"},
            new Product {Id = 9, Name = "Pepsi" , Dept = "SoftDrinks"}
        };

        [ActionName("All")]
        public IEnumerable<Product> GetAll()
        {
            return products;
        }

        [ActionName("rev")]
        public IEnumerable<Product> GetAllReversed()
        {
            return products.Reverse();
        }

        [ActionName("ByID")]
        public IHttpActionResult GetById(int id)
        {
            Product prod = products.FirstOrDefault(x => x.Id == id);
            if (prod == null)
            {
                return NotFound();
            }
            return Ok(prod);
        }

        [ActionName("ByDept")]
        public IHttpActionResult GetByDept(string dept)
        {
            IEnumerable<Product> prod = products.Where(x => x.Dept == dept);
            if (prod == null)
            {
                return NotFound();  // returns HTTP 404
            }
            return Ok(prod);    // returns HTTP 200
        }
    }
}
